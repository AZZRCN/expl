// SevenZipSDK.cpp
#include "SevenZipSDK.h"
#include <iostream>
#include <algorithm>
#include <cstring>

namespace SevenZip {

static std::string WStringToString(const std::wstring& wstr) {
    if (wstr.empty()) return std::string();
    int len = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, NULL, 0, NULL, NULL);
    std::string str(len - 1, 0);
    WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &str[0], len, NULL, NULL);
    return str;
}

static std::wstring StringToWString(const std::string& str) {
    if (str.empty()) return std::wstring();
    int len = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);
    std::wstring wstr(len - 1, 0);
    MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, &wstr[0], len);
    return wstr;
}

static bool FileExists(const std::string& path) {
    DWORD attrib = GetFileAttributesA(path.c_str());
    return (attrib != INVALID_FILE_ATTRIBUTES && !(attrib & FILE_ATTRIBUTE_DIRECTORY));
}

static bool DirectoryExists(const std::string& path) {
    DWORD attrib = GetFileAttributesA(path.c_str());
    return (attrib != INVALID_FILE_ATTRIBUTES && (attrib & FILE_ATTRIBUTE_DIRECTORY));
}

static bool CreateDirectoryRecursive(const std::string& path) {
    if (path.empty()) return true;
    if (DirectoryExists(path)) return true;
    
    std::string current;
    size_t pos = 0;
    while (pos != std::string::npos) {
        size_t nextPos = path.find_first_of("\\/", pos + 1);
        if (nextPos == std::string::npos) break;
        current = path.substr(0, nextPos);
        if (!current.empty() && !DirectoryExists(current)) {
            CreateDirectoryA(current.c_str(), NULL);
        }
        pos = nextPos;
    }
    
    if (!DirectoryExists(path)) {
        return CreateDirectoryA(path.c_str(), NULL) != 0 || GetLastError() == ERROR_ALREADY_EXISTS;
    }
    return true;
}

static bool CreateDirectoryForFile(const std::string& filePath) {
    size_t pos = filePath.rfind('\\');
    if (pos == std::string::npos) pos = filePath.rfind('/');
    if (pos == std::string::npos) return true;
    std::string dirPath = filePath.substr(0, pos);
    return CreateDirectoryRecursive(dirPath);
}

class CInFileStream : public IInStream {
private:
    ULONG _refCount;
    HANDLE _handle;
    std::string _path;
    
public:
    CInFileStream() : _refCount(1), _handle(INVALID_HANDLE_VALUE) {}
    virtual ~CInFileStream() { Close(); }
    
    bool Open(const std::string& path) {
        _path = path;
        std::wstring wpath = StringToWString(path);
        _handle = CreateFileW(wpath.c_str(), GENERIC_READ, FILE_SHARE_READ, 
                              NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
        return _handle != INVALID_HANDLE_VALUE;
    }
    
    void Close() {
        if (_handle != INVALID_HANDLE_VALUE) {
            CloseHandle(_handle);
            _handle = INVALID_HANDLE_VALUE;
        }
    }
    
    Z7_COM7F QueryInterface(const IID& iid, void** outObject) override {
        if (iid == IID_IUnknown || iid == IID_ISequentialInStream || iid == IID_IInStream) {
            *outObject = this;
            AddRef();
            return S_OK;
        }
        *outObject = NULL;
        return E_NOINTERFACE;
    }
    
    ULONG __stdcall AddRef() override { return InterlockedIncrement(&_refCount); }
    ULONG __stdcall Release() override {
        LONG res = InterlockedDecrement(&_refCount);
        if (res == 0) delete this;
        return res;
    }
    
    Z7_COM7F Read(void* data, UInt32 size, UInt32* processedSize) override {
        DWORD bytesRead = 0;
        BOOL result = ReadFile(_handle, data, size, &bytesRead, NULL);
        if (processedSize) *processedSize = bytesRead;
        return result ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    }
    
    Z7_COM7F Seek(Int64 offset, UInt32 seekOrigin, UInt64* newPosition) override {
        LARGE_INTEGER li;
        li.QuadPart = offset;
        LARGE_INTEGER newPos;
        BOOL result = SetFilePointerEx(_handle, li, &newPos, seekOrigin);
        if (newPosition) *newPosition = newPos.QuadPart;
        return result ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    }
};

class COutFileStream : public IOutStream {
private:
    ULONG _refCount;
    HANDLE _handle;
    std::string _path;
    
public:
    COutFileStream() : _refCount(1), _handle(INVALID_HANDLE_VALUE) {}
    virtual ~COutFileStream() { Close(); }
    
    bool Create(const std::string& path) {
        _path = path;
        std::wstring wpath = StringToWString(path);
        _handle = CreateFileW(wpath.c_str(), GENERIC_WRITE, 0, 
                              NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        return _handle != INVALID_HANDLE_VALUE;
    }
    
    void Close() {
        if (_handle != INVALID_HANDLE_VALUE) {
            CloseHandle(_handle);
            _handle = INVALID_HANDLE_VALUE;
        }
    }
    
    Z7_COM7F QueryInterface(const IID& iid, void** outObject) override {
        if (iid == IID_IUnknown || iid == IID_ISequentialOutStream || iid == IID_IOutStream) {
            *outObject = this;
            AddRef();
            return S_OK;
        }
        *outObject = NULL;
        return E_NOINTERFACE;
    }
    
    ULONG __stdcall AddRef() override { return InterlockedIncrement(&_refCount); }
    ULONG __stdcall Release() override {
        LONG res = InterlockedDecrement(&_refCount);
        if (res == 0) delete this;
        return res;
    }
    
    Z7_COM7F Write(const void* data, UInt32 size, UInt32* processedSize) override {
        DWORD bytesWritten = 0;
        BOOL result = WriteFile(_handle, data, size, &bytesWritten, NULL);
        if (processedSize) *processedSize = bytesWritten;
        return result ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    }
    
    Z7_COM7F Seek(Int64 offset, UInt32 seekOrigin, UInt64* newPosition) override {
        LARGE_INTEGER li;
        li.QuadPart = offset;
        LARGE_INTEGER newPos;
        BOOL result = SetFilePointerEx(_handle, li, &newPos, seekOrigin);
        if (newPosition) *newPosition = newPos.QuadPart;
        return result ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    }
    
    Z7_COM7F SetSize(UInt64 newSize) override {
        LARGE_INTEGER li;
        li.QuadPart = newSize;
        LARGE_INTEGER currentPos;
        SetFilePointerEx(_handle, li, &currentPos, FILE_CURRENT);
        BOOL result = SetFilePointerEx(_handle, li, NULL, FILE_BEGIN);
        if (result) {
            result = SetEndOfFile(_handle);
            SetFilePointerEx(_handle, currentPos, NULL, FILE_BEGIN);
        }
        return result ? S_OK : HRESULT_FROM_WIN32(GetLastError());
    }
};

struct CDirItem {
    std::wstring Path;
    std::string FullPath;
    FILETIME CTime;
    FILETIME ATime;
    FILETIME MTime;
    UInt64 Size;
    UInt32 Attrib;
    bool IsDir;
    
    CDirItem() : Size(0), Attrib(0), IsDir(false) {
        memset(&CTime, 0, sizeof(CTime));
        memset(&ATime, 0, sizeof(ATime));
        memset(&MTime, 0, sizeof(MTime));
    }
};

class CArchiveOpenCallback : public IArchiveOpenCallback, public ICryptoGetTextPassword {
private:
    ULONG _refCount;
    
public:
    bool PasswordIsDefined;
    std::wstring Password;
    
    CArchiveOpenCallback() : _refCount(1), PasswordIsDefined(false) {}
    
    Z7_COM7F QueryInterface(const IID& iid, void** outObject) override {
        if (iid == IID_IUnknown || iid == IID_IArchiveOpenCallback) {
            *outObject = static_cast<IArchiveOpenCallback*>(this);
            AddRef();
            return S_OK;
        }
        if (iid == IID_ICryptoGetTextPassword) {
            *outObject = static_cast<ICryptoGetTextPassword*>(this);
            AddRef();
            return S_OK;
        }
        *outObject = NULL;
        return E_NOINTERFACE;
    }
    
    ULONG __stdcall AddRef() override { return InterlockedIncrement(&_refCount); }
    ULONG __stdcall Release() override {
        LONG res = InterlockedDecrement(&_refCount);
        if (res == 0) delete this;
        return res;
    }
    
    Z7_COM7F SetTotal(const UInt64* files, const UInt64* bytes) override { return S_OK; }
    Z7_COM7F SetCompleted(const UInt64* files, const UInt64* bytes) override { return S_OK; }
    
    Z7_COM7F CryptoGetTextPassword(BSTR* password) override {
        if (!PasswordIsDefined) return E_ABORT;
        *password = SysAllocString(Password.c_str());
        return *password ? S_OK : E_OUTOFMEMORY;
    }
};

class CArchiveUpdateCallback : public IArchiveUpdateCallback2, public ICryptoGetTextPassword2 {
private:
    ULONG _refCount;
    const std::vector<CDirItem>* _dirItems;
    std::string _dirPrefix;
    UInt64 _totalSize;
    UInt64 _processedSize;
    std::string _currentFile;
    
public:
    bool PasswordIsDefined;
    std::wstring Password;
    std::function<void(const ProgressInfo&)> ProgressCb;
    std::atomic<bool>* CancelFlag;
    
    CArchiveUpdateCallback() : _refCount(1), _dirItems(nullptr), PasswordIsDefined(false),
        _totalSize(0), _processedSize(0), CancelFlag(nullptr) {}
    
    void Init(const std::vector<CDirItem>* dirItems, const std::string& dirPrefix = "") {
        _dirItems = dirItems;
        _dirPrefix = dirPrefix;
        _processedSize = 0;
        if (_dirItems) {
            _totalSize = dirItems->size();
        }
    }
    
    Z7_COM7F QueryInterface(const IID& iid, void** outObject) override {
        if (iid == IID_IUnknown || iid == IID_IProgress || iid == IID_IArchiveUpdateCallback) {
            *outObject = static_cast<IArchiveUpdateCallback*>(this);
            AddRef();
            return S_OK;
        }
        if (iid == IID_IArchiveUpdateCallback2) {
            *outObject = static_cast<IArchiveUpdateCallback2*>(this);
            AddRef();
            return S_OK;
        }
        if (iid == IID_ICryptoGetTextPassword2) {
            *outObject = static_cast<ICryptoGetTextPassword2*>(this);
            AddRef();
            return S_OK;
        }
        *outObject = NULL;
        return E_NOINTERFACE;
    }
    
    ULONG __stdcall AddRef() override { return InterlockedIncrement(&_refCount); }
    ULONG __stdcall Release() override {
        LONG res = InterlockedDecrement(&_refCount);
        if (res == 0) delete this;
        return res;
    }
    
    Z7_COM7F SetTotal(UInt64 total) override {
        _totalSize = total;
        if (ProgressCb) {
            ProgressInfo info;
            info.totalBytes = total;
            info.totalFiles = (UInt32)_dirItems->size();
            ProgressCb(info);
        }
        return S_OK;
    }
    
    Z7_COM7F SetCompleted(const UInt64* completeValue) override {
        if (CancelFlag && CancelFlag->load()) {
            return E_ABORT;
        }
        if (completeValue && ProgressCb) {
            ProgressInfo info;
            info.completedBytes = *completeValue;
            info.totalBytes = _totalSize;
            info.totalFiles = (UInt32)_dirItems->size();
            if (_totalSize > 0) {
                info.percent = (int)(*completeValue * 100 / _totalSize);
            }
            info.currentFile = _currentFile;
            ProgressCb(info);
        }
        return S_OK;
    }
    
    Z7_COM7F GetUpdateItemInfo(UInt32 index, Int32* newData, Int32* newProperties, UInt32* indexInArchive) override {
        if (newData) *newData = 1;
        if (newProperties) *newProperties = 1;
        if (indexInArchive) *indexInArchive = (UInt32)(Int32)-1;
        return S_OK;
    }
    
    Z7_COM7F GetProperty(UInt32 index, PROPID propID, PROPVARIANT* value) override {
        if (!_dirItems || index >= _dirItems->size()) return E_INVALIDARG;
        
        const CDirItem& di = (*_dirItems)[index];
        PropVariantInit(value);
        
        switch (propID) {
            case kpidPath:
                value->vt = VT_BSTR;
                value->bstrVal = SysAllocString(di.Path.c_str());
                break;
            case kpidIsDir:
                value->vt = VT_BOOL;
                value->boolVal = di.IsDir ? VARIANT_TRUE : VARIANT_FALSE;
                break;
            case kpidSize:
                value->vt = VT_UI8;
                value->uhVal.QuadPart = di.Size;
                break;
            case kpidAttrib:
                value->vt = VT_UI4;
                value->ulVal = di.Attrib;
                break;
            case kpidMTime:
                value->vt = VT_FILETIME;
                value->filetime = di.MTime;
                break;
            case kpidCTime:
                value->vt = VT_FILETIME;
                value->filetime = di.CTime;
                break;
            case kpidATime:
                value->vt = VT_FILETIME;
                value->filetime = di.ATime;
                break;
            case kpidIsAnti:
                value->vt = VT_BOOL;
                value->boolVal = VARIANT_FALSE;
                break;
        }
        return S_OK;
    }
    
    Z7_COM7F GetStream(UInt32 index, ISequentialInStream** inStream) override {
        if (!_dirItems || index >= _dirItems->size()) return E_INVALIDARG;
        
        const CDirItem& di = (*_dirItems)[index];
        if (di.IsDir) return S_OK;
        
        _currentFile = WStringToString(di.Path);
        
        if (ProgressCb) {
            ProgressInfo info;
            info.currentFile = _currentFile;
            info.completedFiles = index;
            info.totalFiles = (UInt32)_dirItems->size();
            ProgressCb(info);
        }
        
        CInFileStream* stream = new CInFileStream();
        if (!stream->Open(di.FullPath)) {
            delete stream;
            return HRESULT_FROM_WIN32(GetLastError());
        }
        
        *inStream = stream;
        return S_OK;
    }
    
    Z7_COM7F SetOperationResult(Int32 operationResult) override {
        _processedSize++;
        return S_OK;
    }
    
    Z7_COM7F GetVolumeSize(UInt32 index, UInt64* size) override { return S_FALSE; }
    Z7_COM7F GetVolumeStream(UInt32 index, ISequentialOutStream** volumeStream) override { return S_FALSE; }
    
    Z7_COM7F CryptoGetTextPassword2(Int32* passwordIsDefined, BSTR* password) override {
        *passwordIsDefined = PasswordIsDefined ? 1 : 0;
        if (PasswordIsDefined) {
            *password = SysAllocString(Password.c_str());
            return *password ? S_OK : E_OUTOFMEMORY;
        }
        *password = NULL;
        return S_OK;
    }
};

class SevenZipCompressorImpl {
public:
    HMODULE _dll;
    Func_CreateObject _createObject;
    std::string _dllPath;
    bool _initialized;
    
    SevenZipCompressorImpl() : _dll(NULL), _createObject(nullptr), _initialized(false) {}
    
    ~SevenZipCompressorImpl() {
        if (_dll) {
            FreeLibrary(_dll);
            _dll = NULL;
        }
    }
    
    bool LoadDLL(const std::string& dllPath) {
        _dllPath = dllPath;
        std::wstring wpath = StringToWString(dllPath);
        _dll = LoadLibraryW(wpath.c_str());
        if (!_dll) return false;
        
        _createObject = (Func_CreateObject)GetProcAddress(_dll, "CreateObject");
        if (!_createObject) {
            FreeLibrary(_dll);
            _dll = NULL;
            return false;
        }
        return true;
    }
    
    HRESULT SetCompressionProperties(IOutArchive* outArchive, const CompressionOptions& options) {
        CMyComPtr<ISetProperties> setProperties;
        HRESULT hr = outArchive->QueryInterface(IID_ISetProperties, (void**)&setProperties);
        if (hr != S_OK || !setProperties) return hr;
        
        std::vector<const wchar_t*> names;
        std::vector<PROPVARIANT> values;
        
        PROPVARIANT prop;
        PropVariantInit(&prop);
        
        prop.vt = VT_UI4;
        prop.ulVal = static_cast<UInt32>(options.level);
        names.push_back(L"x");
        values.push_back(prop);
        
        if (options.method != CompressionMethod::COPY) {
            prop.vt = VT_BSTR;
            std::string methodName = SevenZipCompressor::GetCompressionMethodName(options.method);
            std::wstring wmethod = StringToWString(methodName);
            prop.bstrVal = SysAllocString(wmethod.c_str());
            names.push_back(L"0");
            values.push_back(prop);
        }
        
        if (!options.solidMode) {
            prop.vt = VT_BOOL;
            prop.boolVal = VARIANT_FALSE;
            names.push_back(L"s");
            values.push_back(prop);
        }
        
        if (!options.dictionarySize.empty()) {
            prop.vt = VT_BSTR;
            std::wstring wdict = StringToWString(options.dictionarySize);
            prop.bstrVal = SysAllocString(wdict.c_str());
            names.push_back(L"0d");
            values.push_back(prop);
        }
        
        if (!options.wordSize.empty()) {
            prop.vt = VT_BSTR;
            std::wstring wword = StringToWString(options.wordSize);
            prop.bstrVal = SysAllocString(wword.c_str());
            names.push_back(L"0w");
            values.push_back(prop);
        }
        
        if (options.threadCount > 0) {
            prop.vt = VT_UI4;
            prop.ulVal = options.threadCount;
            names.push_back(L"mt");
            values.push_back(prop);
        }
        
        if (options.encryptHeaders && !options.password.empty()) {
            prop.vt = VT_BOOL;
            prop.boolVal = VARIANT_TRUE;
            names.push_back(L"he");
            values.push_back(prop);
        }
        
        hr = setProperties->SetProperties(names.data(), values.data(), (UInt32)names.size());
        
        for (size_t i = 0; i < values.size(); i++) {
            if (values[i].vt == VT_BSTR && values[i].bstrVal) {
                SysFreeString(values[i].bstrVal);
            }
        }
        
        return hr;
    }
    
    GUID GetFormatCLSID(const std::string& archivePath) {
        size_t pos = archivePath.rfind('.');
        if (pos == std::string::npos) return CLSID_CFormat7z;
        
        std::string ext = archivePath.substr(pos + 1);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        
        if (ext == "7z") return CLSID_CFormat7z;
        if (ext == "zip") return CLSID_CFormatZip;
        if (ext == "gz" || ext == "gzip") return CLSID_CFormatGZip;
        if (ext == "bz2" || ext == "bzip2") return CLSID_CFormatBZip2;
        if (ext == "xz") return CLSID_CFormatXz;
        if (ext == "tar") return CLSID_CFormatTar;
        
        return CLSID_CFormat7z;
    }
    
    bool EnumerateFiles(const std::string& directory, std::vector<CDirItem>& items, bool recursive, const std::string& baseDir = "") {
        std::string searchPath = directory + "\\*";
        std::wstring wsearchPath = StringToWString(searchPath);
        
        WIN32_FIND_DATAW findData;
        HANDLE hFind = FindFirstFileW(wsearchPath.c_str(), &findData);
        if (hFind == INVALID_HANDLE_VALUE) return false;
        
        bool hasFiles = false;
        std::string effectiveBase = baseDir.empty() ? directory : baseDir;
        
        do {
            std::wstring name = findData.cFileName;
            if (name == L"." || name == L"..") continue;
            
            CDirItem item;
            std::string fileName = WStringToString(name);
            std::string fullFilePath = directory + "\\" + fileName;
            
            item.Path = name;
            item.FullPath = fullFilePath;
            item.Size = ((UInt64)findData.nFileSizeHigh << 32) | findData.nFileSizeLow;
            item.Attrib = findData.dwFileAttributes;
            item.IsDir = (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
            item.CTime = findData.ftCreationTime;
            item.ATime = findData.ftLastAccessTime;
            item.MTime = findData.ftLastWriteTime;
            
            if (item.IsDir) {
                if (recursive) {
                    std::vector<CDirItem> subItems;
                    bool subHasFiles = EnumerateFiles(fullFilePath, subItems, recursive, effectiveBase);
                    for (auto& subItem : subItems) {
                        subItem.Path = name + L"\\" + subItem.Path;
                        items.push_back(subItem);
                    }
                    if (!subHasFiles) {
                        items.push_back(item);
                    }
                    hasFiles = hasFiles || subHasFiles;
                }
            } else {
                items.push_back(item);
                hasFiles = true;
            }
        } while (FindNextFileW(hFind, &findData));
        
        FindClose(hFind);
        return hasFiles;
    }
};

SevenZipCompressor::SevenZipCompressor(const std::string& dllPath)
    : m_dllPath(dllPath), m_impl(new SevenZipCompressorImpl()), 
      m_cancelFlag(false), m_asyncStatus(AsyncStatus::Idle) {
}

SevenZipCompressor::~SevenZipCompressor() {
    Cancel();
    WaitForCompletion();
}

bool SevenZipCompressor::Initialize() {
    if (!m_impl->LoadDLL(m_dllPath)) return false;
    m_impl->_initialized = true;
    return true;
}

bool SevenZipCompressor::IsInitialized() const {
    return m_impl && m_impl->_initialized;
}

ProgressInfo SevenZipCompressor::GetProgress() const {
    std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(m_mutex));
    return m_currentProgress;
}

void SevenZipCompressor::Cancel() {
    m_cancelFlag = true;
}

void SevenZipCompressor::WaitForCompletion() {
    if (m_workerThread.joinable()) {
        m_workerThread.join();
    }
}

bool SevenZipCompressor::CompressFiles(
    const std::string& archivePath,
    const std::vector<std::string>& filePaths,
    const CompressionOptions& options) {
    
    if (!IsInitialized() && !Initialize()) return false;
    if (filePaths.empty()) return false;
    
    std::vector<CDirItem> dirItems;
    for (const auto& file : filePaths) {
        if (!FileExists(file)) continue;
        
        WIN32_FILE_ATTRIBUTE_DATA attr;
        std::wstring wfile = StringToWString(file);
        if (!GetFileAttributesExW(wfile.c_str(), GetFileExInfoStandard, &attr)) continue;
        
        CDirItem item;
        size_t pos = file.rfind('\\');
        item.Path = StringToWString(pos != std::string::npos ? file.substr(pos + 1) : file);
        item.FullPath = file;
        item.Size = ((UInt64)attr.nFileSizeHigh << 32) | attr.nFileSizeLow;
        item.Attrib = attr.dwFileAttributes;
        item.IsDir = false;
        item.CTime = attr.ftCreationTime;
        item.ATime = attr.ftLastAccessTime;
        item.MTime = attr.ftLastWriteTime;
        dirItems.push_back(item);
    }
    
    if (dirItems.empty()) return false;
    
    COutFileStream* outFileStream = new COutFileStream();
    if (!outFileStream->Create(archivePath)) {
        outFileStream->Release();
        return false;
    }
    
    GUID formatID = m_impl->GetFormatCLSID(archivePath);
    IOutArchive* outArchive = nullptr;
    HRESULT hr = m_impl->_createObject(&formatID, &IID_IOutArchive, (void**)&outArchive);
    
    if (hr != S_OK || !outArchive) {
        outFileStream->Release();
        return false;
    }
    
    m_impl->SetCompressionProperties(outArchive, options);
    
    CArchiveUpdateCallback* updateCallback = new CArchiveUpdateCallback();
    updateCallback->Init(&dirItems);
    updateCallback->PasswordIsDefined = !options.password.empty();
    updateCallback->Password = StringToWString(options.password);
    updateCallback->CancelFlag = &m_cancelFlag;
    
    if (m_progressCallback) {
        updateCallback->ProgressCb = [this](const ProgressInfo& info) {
            {
                std::lock_guard<std::mutex> lock(m_mutex);
                m_currentProgress = info;
            }
            m_progressCallback(info);
        };
    }
    
    hr = outArchive->UpdateItems(outFileStream, (UInt32)dirItems.size(), updateCallback);
    
    updateCallback->Release();
    outArchive->Release();
    outFileStream->Release();
    
    return hr == S_OK;
}

bool SevenZipCompressor::CompressDirectory(
    const std::string& archivePath,
    const std::string& directoryPath,
    const CompressionOptions& options,
    bool recursive) {
    
    if (!IsInitialized() && !Initialize()) return false;
    if (!DirectoryExists(directoryPath)) return false;
    
    std::vector<CDirItem> dirItems;
    m_impl->EnumerateFiles(directoryPath, dirItems, recursive);
    
    if (dirItems.empty()) return false;
    
    COutFileStream* outFileStream = new COutFileStream();
    if (!outFileStream->Create(archivePath)) {
        outFileStream->Release();
        return false;
    }
    
    GUID formatID = m_impl->GetFormatCLSID(archivePath);
    IOutArchive* outArchive = nullptr;
    HRESULT hr = m_impl->_createObject(&formatID, &IID_IOutArchive, (void**)&outArchive);
    
    if (hr != S_OK || !outArchive) {
        outFileStream->Release();
        return false;
    }
    
    m_impl->SetCompressionProperties(outArchive, options);
    
    CArchiveUpdateCallback* updateCallback = new CArchiveUpdateCallback();
    updateCallback->Init(&dirItems);
    updateCallback->PasswordIsDefined = !options.password.empty();
    updateCallback->Password = StringToWString(options.password);
    updateCallback->CancelFlag = &m_cancelFlag;
    
    if (m_progressCallback) {
        updateCallback->ProgressCb = [this](const ProgressInfo& info) {
            {
                std::lock_guard<std::mutex> lock(m_mutex);
                m_currentProgress = info;
            }
            m_progressCallback(info);
        };
    }
    
    hr = outArchive->UpdateItems(outFileStream, (UInt32)dirItems.size(), updateCallback);
    
    updateCallback->Release();
    outArchive->Release();
    outFileStream->Release();
    
    return hr == S_OK;
}

void SevenZipCompressor::CompressFilesAsync(
    const std::string& archivePath,
    const std::vector<std::string>& filePaths,
    const CompressionOptions& options) {
    
    WaitForCompletion();
    m_cancelFlag = false;
    m_asyncStatus = AsyncStatus::Running;
    
    m_workerThread = std::thread([this, archivePath, filePaths, options]() {
        bool success = CompressFiles(archivePath, filePaths, options);
        
        if (m_cancelFlag.load()) {
            m_asyncStatus = AsyncStatus::Cancelled;
        } else if (success) {
            m_asyncStatus = AsyncStatus::Completed;
        } else {
            m_asyncStatus = AsyncStatus::Failed;
        }
        
        if (m_completeCallback) {
            m_completeCallback(success, archivePath);
        }
    });
}

void SevenZipCompressor::CompressDirectoryAsync(
    const std::string& archivePath,
    const std::string& directoryPath,
    const CompressionOptions& options,
    bool recursive) {
    
    WaitForCompletion();
    m_cancelFlag = false;
    m_asyncStatus = AsyncStatus::Running;
    
    m_workerThread = std::thread([this, archivePath, directoryPath, options, recursive]() {
        bool success = CompressDirectory(archivePath, directoryPath, options, recursive);
        
        if (m_cancelFlag.load()) {
            m_asyncStatus = AsyncStatus::Cancelled;
        } else if (success) {
            m_asyncStatus = AsyncStatus::Completed;
        } else {
            m_asyncStatus = AsyncStatus::Failed;
        }
        
        if (m_completeCallback) {
            m_completeCallback(success, archivePath);
        }
    });
}

bool SevenZipCompressor::ExtractArchive(
    const std::string& archivePath,
    const ExtractOptions& options) {
    
    if (!IsInitialized() && !Initialize()) return false;
    if (!FileExists(archivePath)) return false;
    
    if (!options.outputDir.empty() && !DirectoryExists(options.outputDir)) {
        CreateDirectoryRecursive(options.outputDir);
    }
    
    CInFileStream* inFile = new CInFileStream();
    if (!inFile->Open(archivePath)) {
        inFile->Release();
        return false;
    }
    
    GUID formatID = m_impl->GetFormatCLSID(archivePath);
    IInArchive* inArchive = nullptr;
    HRESULT hr = m_impl->_createObject(&formatID, &IID_IInArchive, (void**)&inArchive);
    
    if (hr != S_OK || !inArchive) {
        inFile->Release();
        return false;
    }
    
    CArchiveOpenCallback* openCallback = new CArchiveOpenCallback();
    openCallback->PasswordIsDefined = !options.password.empty();
    openCallback->Password = StringToWString(options.password);
    
    UInt64 scanSize = 1 << 23;
    hr = inArchive->Open(inFile, &scanSize, openCallback);
    openCallback->Release();
    
    if (hr != S_OK) {
        inArchive->Release();
        inFile->Release();
        return false;
    }
    
    UInt32 numItems = 0;
    inArchive->GetNumberOfItems(&numItems);
    
    for (UInt32 i = 0; i < numItems; i++) {
        PROPVARIANT prop;
        PropVariantInit(&prop);
        inArchive->GetProperty(i, kpidPath, &prop);
        
        std::string path;
        if (prop.vt == VT_BSTR) {
            path = WStringToString(prop.bstrVal);
        }
        PropVariantClear(&prop);
        
        prop.vt = VT_EMPTY;
        inArchive->GetProperty(i, kpidIsDir, &prop);
        bool isDir = (prop.vt == VT_BOOL && prop.boolVal != VARIANT_FALSE);
        PropVariantClear(&prop);
        
        if (!isDir) {
            std::string fullPath = options.outputDir.empty() ? path : options.outputDir + "\\" + path;
            CreateDirectoryForFile(fullPath);
            
            prop.vt = VT_EMPTY;
            inArchive->GetProperty(i, kpidSize, &prop);
            UInt64 size = 0;
            if (prop.vt == VT_UI8) size = prop.uhVal.QuadPart;
            PropVariantClear(&prop);
            
            COutFileStream* outFile = new COutFileStream();
            if (outFile->Create(fullPath)) {
                char buffer[8192];
                UInt64 remaining = size;
                
                while (remaining > 0) {
                    UInt32 toRead = (UInt32)std::min(remaining, (UInt64)sizeof(buffer));
                    UInt32 bytesRead = 0;
                    
                    ISequentialInStream* inStream = nullptr;
                    PROPVARIANT pathProp;
                    PropVariantInit(&pathProp);
                    pathProp.vt = VT_BSTR;
                    pathProp.bstrVal = SysAllocString(StringToWString(path).c_str());
                    
                    UInt32 processed = 0;
                    while (remaining > 0 && !m_cancelFlag.load()) {
                        toRead = (UInt32)std::min(remaining, (UInt64)sizeof(buffer));
                        bytesRead = 0;
                        
                        if (m_progressCallback) {
                            ProgressInfo info;
                            info.currentFile = path;
                            info.completedBytes = size - remaining;
                            info.totalBytes = size;
                            info.percent = (int)((size - remaining) * 100 / size);
                            m_progressCallback(info);
                        }
                        
                        remaining -= bytesRead;
                    }
                    break;
                }
            }
            outFile->Release();
        } else {
            CreateDirectoryRecursive(options.outputDir.empty() ? path : options.outputDir + "\\" + path);
        }
    }
    
    inArchive->Close();
    inArchive->Release();
    inFile->Release();
    
    return true;
}

bool SevenZipCompressor::TestArchive(const std::string& archivePath, const std::string& password) {
    if (!IsInitialized() && !Initialize()) return false;
    if (!FileExists(archivePath)) return false;
    
    CInFileStream* inFile = new CInFileStream();
    if (!inFile->Open(archivePath)) {
        inFile->Release();
        return false;
    }
    
    GUID formatID = m_impl->GetFormatCLSID(archivePath);
    IInArchive* inArchive = nullptr;
    HRESULT hr = m_impl->_createObject(&formatID, &IID_IInArchive, (void**)&inArchive);
    
    if (hr != S_OK || !inArchive) {
        inFile->Release();
        return false;
    }
    
    CArchiveOpenCallback* openCallback = new CArchiveOpenCallback();
    openCallback->PasswordIsDefined = !password.empty();
    openCallback->Password = StringToWString(password);
    
    UInt64 scanSize = 1 << 23;
    hr = inArchive->Open(inFile, &scanSize, openCallback);
    openCallback->Release();
    
    bool result = (hr == S_OK);
    if (result) {
        inArchive->Close();
    }
    
    inArchive->Release();
    inFile->Release();
    
    return result;
}

bool SevenZipCompressor::ListArchive(const std::string& archivePath, ArchiveInfo& info, const std::string& password) {
    if (!IsInitialized() && !Initialize()) return false;
    if (!FileExists(archivePath)) return false;
    
    CInFileStream* inFile = new CInFileStream();
    if (!inFile->Open(archivePath)) {
        inFile->Release();
        return false;
    }
    
    GUID formatID = m_impl->GetFormatCLSID(archivePath);
    IInArchive* inArchive = nullptr;
    HRESULT hr = m_impl->_createObject(&formatID, &IID_IInArchive, (void**)&inArchive);
    
    if (hr != S_OK || !inArchive) {
        inFile->Release();
        return false;
    }
    
    CArchiveOpenCallback* openCallback = new CArchiveOpenCallback();
    openCallback->PasswordIsDefined = !password.empty();
    openCallback->Password = StringToWString(password);
    
    UInt64 scanSize = 1 << 23;
    hr = inArchive->Open(inFile, &scanSize, openCallback);
    openCallback->Release();
    
    if (hr != S_OK) {
        inArchive->Release();
        inFile->Release();
        return false;
    }
    
    info = ArchiveInfo();
    info.path = archivePath;
    
    UInt32 numItems = 0;
    inArchive->GetNumberOfItems(&numItems);
    
    for (UInt32 i = 0; i < numItems; i++) {
        FileInfo fi;
        
        PROPVARIANT prop;
        PropVariantInit(&prop);
        
        inArchive->GetProperty(i, kpidPath, &prop);
        if (prop.vt == VT_BSTR) fi.path = WStringToString(prop.bstrVal);
        PropVariantClear(&prop);
        
        inArchive->GetProperty(i, kpidSize, &prop);
        if (prop.vt == VT_UI8) fi.size = prop.uhVal.QuadPart;
        PropVariantClear(&prop);
        
        inArchive->GetProperty(i, kpidIsDir, &prop);
        if (prop.vt == VT_BOOL) fi.isDirectory = (prop.boolVal != VARIANT_FALSE);
        PropVariantClear(&prop);
        
        info.files.push_back(fi);
        
        if (fi.isDirectory) info.directoryCount++;
        else { info.fileCount++; info.uncompressedSize += fi.size; }
    }
    
    inArchive->Close();
    inArchive->Release();
    inFile->Release();
    
    return true;
}

std::string SevenZipCompressor::GetCompressionMethodName(CompressionMethod method) {
    switch (method) {
        case CompressionMethod::LZMA: return "lzma";
        case CompressionMethod::LZMA2: return "lzma2";
        case CompressionMethod::PPMD: return "ppmd";
        case CompressionMethod::BZIP2: return "bzip2";
        case CompressionMethod::DEFLATE: return "deflate";
        case CompressionMethod::COPY: return "copy";
        default: return "lzma2";
    }
}

std::string SevenZipCompressor::GetFormatExtension(ArchiveFormat format) {
    switch (format) {
        case ArchiveFormat::FMT_7Z: return ".7z";
        case ArchiveFormat::FMT_ZIP: return ".zip";
        case ArchiveFormat::FMT_GZIP: return ".gz";
        case ArchiveFormat::FMT_BZIP2: return ".bz2";
        case ArchiveFormat::FMT_XZ: return ".xz";
        case ArchiveFormat::FMT_TAR: return ".tar";
        default: return ".7z";
    }
}

ArchiveFormat SevenZipCompressor::DetectFormatFromExtension(const std::string& path) {
    size_t pos = path.rfind('.');
    if (pos == std::string::npos) return ArchiveFormat::FMT_7Z;
    
    std::string ext = path.substr(pos);
    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
    
    if (ext == ".7z") return ArchiveFormat::FMT_7Z;
    if (ext == ".zip") return ArchiveFormat::FMT_ZIP;
    if (ext == ".gz" || ext == ".gzip") return ArchiveFormat::FMT_GZIP;
    if (ext == ".bz2" || ext == ".bzip2") return ArchiveFormat::FMT_BZIP2;
    if (ext == ".xz") return ArchiveFormat::FMT_XZ;
    if (ext == ".tar") return ArchiveFormat::FMT_TAR;
    
    return ArchiveFormat::FMT_7Z;
}

}
