// SevenZipSDK.h
// 7-Zip SDK Interface Definitions for direct DLL calls
#pragma once

#ifdef _WIN32
#include <windows.h>
#endif

#include <string>
#include <vector>
#include <functional>
#include <memory>
#include <cstdint>
#include <atomic>
#include <thread>
#include <mutex>

namespace SevenZip {

typedef int32_t Int32;
typedef uint32_t UInt32;
typedef int64_t Int64;
typedef uint64_t UInt64;

typedef GUID IID;
typedef GUID CLSID;

#define Z7_COM7F HRESULT __stdcall

#define RINOK(x) { HRESULT __result_ = (x); if (__result_ != S_OK) return __result_; }

static const IID IID_IUnknown = { 0x00000000, 0x0000, 0x0000, { 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46 } };
static const IID IID_ISequentialInStream = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x03, 0x00, 0x01, 0x00, 0x00 } };
static const IID IID_ISequentialOutStream = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x03, 0x00, 0x02, 0x00, 0x00 } };
static const IID IID_IInStream = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x03, 0x00, 0x03, 0x00, 0x00 } };
static const IID IID_IOutStream = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x03, 0x00, 0x04, 0x00, 0x00 } };
static const IID IID_IStreamGetSize = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x03, 0x00, 0x06, 0x00, 0x00 } };
static const IID IID_IInArchive = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0x60, 0x00, 0x00 } };
static const IID IID_IOutArchive = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0xA0, 0x00, 0x00 } };
static const IID IID_IArchiveOpenCallback = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0x10, 0x00, 0x00 } };
static const IID IID_IArchiveExtractCallback = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0x20, 0x00, 0x00 } };
static const IID IID_IArchiveUpdateCallback = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0x80, 0x00, 0x00 } };
static const IID IID_IArchiveUpdateCallback2 = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0x82, 0x00, 0x00 } };
static const IID IID_ICryptoGetTextPassword = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x05, 0x00, 0x10, 0x00, 0x00 } };
static const IID IID_ICryptoGetTextPassword2 = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x05, 0x00, 0x11, 0x00, 0x00 } };
static const IID IID_ISetProperties = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x06, 0x00, 0x03, 0x00, 0x00 } };
static const IID IID_IProgress = { 0x23170F69, 0x40C1, 0x278A, { 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00 } };

enum PropID
{
    kpidPath = 3,
    kpidSize = 7,
    kpidPackSize = 8,
    kpidAttrib = 11,
    kpidCTime = 12,
    kpidATime = 13,
    kpidMTime = 14,
    kpidIsDir = 23,
    kpidEncrypted = 25,
    kpidMethod = 30,
    kpidSolid = 31,
    kpidIsAnti = 34,
    kpidPosixAttrib = 48
};

enum ExtractAskMode
{
    kExtract = 0,
    kTest,
    kSkip,
    kReadExternal
};

enum ExtractOperationResult
{
    kOK = 0,
    kUnsupportedMethod,
    kDataError,
    kCRCError,
    kUnavailable,
    kUnexpectedEnd,
    kDataAfterEnd,
    kIsNotArc,
    kHeadersError,
    kWrongPassword
};

#define DEFINE_GUID_ARC(name, id) \
static const GUID name = { 0x23170F69, 0x40C1, 0x278A, { 0x10, 0x00, 0x00, 0x01, 0x10, id, 0x00, 0x00 } };

DEFINE_GUID_ARC(CLSID_CFormat7z, 0x07)
DEFINE_GUID_ARC(CLSID_CFormatZip, 0x01)
DEFINE_GUID_ARC(CLSID_CFormatBZip2, 0x02)
DEFINE_GUID_ARC(CLSID_CFormatRar, 0x03)
DEFINE_GUID_ARC(CLSID_CFormatTar, 0xEE)
DEFINE_GUID_ARC(CLSID_CFormatGZip, 0xEF)
DEFINE_GUID_ARC(CLSID_CFormatXz, 0x0C)

struct IUnknown
{
    virtual Z7_COM7F QueryInterface(const IID& iid, void** outObject) = 0;
    virtual ULONG __stdcall AddRef() = 0;
    virtual ULONG __stdcall Release() = 0;
};

struct ISequentialInStream : public IUnknown
{
    virtual Z7_COM7F Read(void* data, UInt32 size, UInt32* processedSize) = 0;
};

struct ISequentialOutStream : public IUnknown
{
    virtual Z7_COM7F Write(const void* data, UInt32 size, UInt32* processedSize) = 0;
};

struct IInStream : public ISequentialInStream
{
    virtual Z7_COM7F Seek(Int64 offset, UInt32 seekOrigin, UInt64* newPosition) = 0;
};

struct IOutStream : public ISequentialOutStream
{
    virtual Z7_COM7F Seek(Int64 offset, UInt32 seekOrigin, UInt64* newPosition) = 0;
    virtual Z7_COM7F SetSize(UInt64 newSize) = 0;
};

struct IStreamGetSize : public IUnknown
{
    virtual Z7_COM7F GetSize(UInt64* size) = 0;
};

struct IProgress : public IUnknown
{
    virtual Z7_COM7F SetTotal(UInt64 total) = 0;
    virtual Z7_COM7F SetCompleted(const UInt64* completeValue) = 0;
};

struct IArchiveOpenCallback : public IUnknown
{
    virtual Z7_COM7F SetTotal(const UInt64* files, const UInt64* bytes) = 0;
    virtual Z7_COM7F SetCompleted(const UInt64* files, const UInt64* bytes) = 0;
};

struct IArchiveExtractCallback : public IProgress
{
    virtual Z7_COM7F GetStream(UInt32 index, ISequentialOutStream** outStream, Int32 askExtractMode) = 0;
    virtual Z7_COM7F PrepareOperation(Int32 askExtractMode) = 0;
    virtual Z7_COM7F SetOperationResult(Int32 operationResult) = 0;
};

struct IArchiveUpdateCallback : public IProgress
{
    virtual Z7_COM7F GetUpdateItemInfo(UInt32 index, Int32* newData, Int32* newProperties, UInt32* indexInArchive) = 0;
    virtual Z7_COM7F GetProperty(UInt32 index, PROPID propID, PROPVARIANT* value) = 0;
    virtual Z7_COM7F GetStream(UInt32 index, ISequentialInStream** inStream) = 0;
    virtual Z7_COM7F SetOperationResult(Int32 operationResult) = 0;
};

struct IArchiveUpdateCallback2 : public IArchiveUpdateCallback
{
    virtual Z7_COM7F GetVolumeSize(UInt32 index, UInt64* size) = 0;
    virtual Z7_COM7F GetVolumeStream(UInt32 index, ISequentialOutStream** volumeStream) = 0;
};

struct ICryptoGetTextPassword : public IUnknown
{
    virtual Z7_COM7F CryptoGetTextPassword(BSTR* password) = 0;
};

struct ICryptoGetTextPassword2 : public IUnknown
{
    virtual Z7_COM7F CryptoGetTextPassword2(Int32* passwordIsDefined, BSTR* password) = 0;
};

struct IInArchive : public IUnknown
{
    virtual Z7_COM7F Open(IInStream* stream, const UInt64* maxCheckStartPosition, IArchiveOpenCallback* openCallback) = 0;
    virtual Z7_COM7F Close() = 0;
    virtual Z7_COM7F GetNumberOfItems(UInt32* numItems) = 0;
    virtual Z7_COM7F GetProperty(UInt32 index, PROPID propID, PROPVARIANT* value) = 0;
    virtual Z7_COM7F Extract(const UInt32* indices, UInt32 numItems, Int32 testMode, IArchiveExtractCallback* extractCallback) = 0;
    virtual Z7_COM7F GetArchiveProperty(PROPID propID, PROPVARIANT* value) = 0;
    virtual Z7_COM7F GetNumberOfProperties(UInt32* numProps) = 0;
    virtual Z7_COM7F GetPropertyInfo(UInt32 index, BSTR* name, PROPID* propID, VARTYPE* varType) = 0;
    virtual Z7_COM7F GetNumberOfArchiveProperties(UInt32* numProps) = 0;
    virtual Z7_COM7F GetArchivePropertyInfo(UInt32 index, BSTR* name, PROPID* propID, VARTYPE* varType) = 0;
};

struct IOutArchive : public IUnknown
{
    virtual Z7_COM7F UpdateItems(ISequentialOutStream* outStream, UInt32 numItems, IArchiveUpdateCallback* updateCallback) = 0;
    virtual Z7_COM7F GetFileTimeType(UInt32* type) = 0;
};

struct ISetProperties : public IUnknown
{
    virtual Z7_COM7F SetProperties(const wchar_t* const* names, const PROPVARIANT* values, UInt32 numProps) = 0;
};

typedef HRESULT (WINAPI* Func_CreateObject)(const GUID* clsID, const GUID* iid, void** outObject);

template <class T>
class CMyComPtr
{
    T* _p;
public:
    CMyComPtr() : _p(NULL) {}
    CMyComPtr(T* p) : _p(p) { if (_p) _p->AddRef(); }
    CMyComPtr(const CMyComPtr<T>& cp) : _p(cp._p) { if (_p) _p->AddRef(); }
    ~CMyComPtr() { if (_p) _p->Release(); }
    
    CMyComPtr& operator=(T* p) {
        if (_p) _p->Release();
        _p = p;
        if (_p) _p->AddRef();
        return *this;
    }
    
    T* operator->() const { return _p; }
    operator T*() const { return _p; }
    T** operator&() { return &_p; }
    T* Detach() { T* p = _p; _p = NULL; return p; }
    void Release() { if (_p) { _p->Release(); _p = NULL; } }
};

enum class CompressionLevel {
    None = 0,
    Fastest = 1,
    Fast = 3,
    Normal = 5,
    Maximum = 7,
    Ultra = 9
};

enum class CompressionMethod {
    LZMA,
    LZMA2,
    PPMD,
    BZIP2,
    DEFLATE,
    COPY
};

enum class ArchiveFormat {
    FMT_7Z,
    FMT_ZIP,
    FMT_GZIP,
    FMT_BZIP2,
    FMT_XZ,
    FMT_TAR
};

enum class AsyncStatus {
    Idle,
    Running,
    Completed,
    Failed,
    Cancelled
};

struct CompressionOptions {
    CompressionLevel level = CompressionLevel::Normal;
    CompressionMethod method = CompressionMethod::LZMA2;
    bool solidMode = true;
    bool encryptHeaders = false;
    std::string password;
    uint64_t volumeSize = 0;
    int threadCount = 0;
    std::string dictionarySize;
    std::string wordSize;
};

struct FileInfo {
    std::string path;
    uint64_t size;
    uint32_t attributes;
    bool isDirectory;
};

struct ExtractOptions {
    std::string outputDir;
    std::string password;
    bool overwriteExisting = true;
    bool preserveDirectoryStructure = true;
};

struct ArchiveInfo {
    std::string path;
    uint64_t uncompressedSize;
    uint64_t compressedSize;
    uint32_t fileCount;
    uint32_t directoryCount;
    bool isEncrypted;
    std::string method;
    std::vector<FileInfo> files;
};

struct ProgressInfo {
    uint64_t totalBytes = 0;
    uint64_t completedBytes = 0;
    uint32_t totalFiles = 0;
    uint32_t completedFiles = 0;
    std::string currentFile;
    int percent = 0;
};

using ProgressCallback = std::function<void(const ProgressInfo& info)>;
using ErrorCallback = std::function<void(const std::string& error, const std::string& file)>;
using CompleteCallback = std::function<void(bool success, const std::string& archivePath)>;

class SevenZipCompressorImpl;

class SevenZipCompressor {
private:
    std::string m_dllPath;
    std::unique_ptr<SevenZipCompressorImpl> m_impl;
    ProgressCallback m_progressCallback;
    ErrorCallback m_errorCallback;
    CompleteCallback m_completeCallback;
    std::atomic<bool> m_cancelFlag;
    std::atomic<AsyncStatus> m_asyncStatus;
    std::thread m_workerThread;
    std::mutex m_mutex;
    ProgressInfo m_currentProgress;
    
public:
    SevenZipCompressor(const std::string& dllPath = "7z.dll");
    ~SevenZipCompressor();
    
    bool Initialize();
    bool IsInitialized() const;
    
    void SetProgressCallback(ProgressCallback callback) { m_progressCallback = callback; }
    void SetErrorCallback(ErrorCallback callback) { m_errorCallback = callback; }
    void SetCompleteCallback(CompleteCallback callback) { m_completeCallback = callback; }
    
    bool CompressFiles(
        const std::string& archivePath,
        const std::vector<std::string>& filePaths,
        const CompressionOptions& options = CompressionOptions()
    );
    
    bool CompressDirectory(
        const std::string& archivePath,
        const std::string& directoryPath,
        const CompressionOptions& options = CompressionOptions(),
        bool recursive = true
    );
    
    void CompressFilesAsync(
        const std::string& archivePath,
        const std::vector<std::string>& filePaths,
        const CompressionOptions& options = CompressionOptions()
    );
    
    void CompressDirectoryAsync(
        const std::string& archivePath,
        const std::string& directoryPath,
        const CompressionOptions& options = CompressionOptions(),
        bool recursive = true
    );
    
    void Cancel();
    bool IsRunning() const { return m_asyncStatus == AsyncStatus::Running; }
    AsyncStatus GetStatus() const { return m_asyncStatus; }
    ProgressInfo GetProgress() const;
    void WaitForCompletion();
    
    bool ExtractArchive(
        const std::string& archivePath,
        const ExtractOptions& options = ExtractOptions()
    );
    
    bool ExtractFiles(
        const std::string& archivePath,
        const std::vector<std::string>& filesToExtract,
        const std::string& outputDir,
        const std::string& password = ""
    );
    
    bool TestArchive(
        const std::string& archivePath,
        const std::string& password = ""
    );
    
    bool ListArchive(
        const std::string& archivePath,
        ArchiveInfo& info,
        const std::string& password = ""
    );
    
    static std::string GetCompressionMethodName(CompressionMethod method);
    static std::string GetFormatExtension(ArchiveFormat format);
    static ArchiveFormat DetectFormatFromExtension(const std::string& path);
};

}
