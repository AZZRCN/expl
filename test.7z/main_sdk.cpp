// main_sdk.cpp
#include "SevenZipSDK.h"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <thread>

using namespace SevenZip;

void PrintProgress(const ProgressInfo& info) {
    std::cout << "\rProgress: " << std::setw(3) << info.percent << "% | ";
    std::cout << "File: " << std::setw(30) << std::left << info.currentFile.substr(0, 30);
    std::cout << std::flush;
}

void OnComplete(bool success, const std::string& archivePath) {
    std::cout << std::endl;
    if (success) {
        std::cout << "Completed: " << archivePath << std::endl;
    } else {
        std::cout << "Failed!" << std::endl;
    }
}

int main() {
    std::cout << "=== 7-Zip SDK Test ===" << std::endl;
    
    SevenZipCompressor compressor("7z.dll");
    
    if (!compressor.Initialize()) {
        std::cerr << "Failed to initialize!" << std::endl;
        return 1;
    }
    
    compressor.SetProgressCallback(PrintProgress);
    compressor.SetCompleteCallback(OnComplete);
    
    CompressionOptions options;
    options.level = CompressionLevel::Ultra;
    
    std::cout << "\n--- Compress Directory Test ---" << std::endl;
    
    compressor.CompressDirectoryAsync("test.7z", "E:\\expl\\7z\\", options, true);
    
    while (compressor.IsRunning()) {
        ProgressInfo info = compressor.GetProgress();
        std::cout << "\rProgress: " << std::setw(3) << info.percent << "% | ";
        std::cout << "Files: " << std::setw(4) << info.completedFiles << "/" << info.totalFiles << " | ";
        std::cout << std::setw(30) << std::left << info.currentFile.substr(0, 30);
        std::cout << std::flush;
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    
    compressor.WaitForCompletion();
    
    if (compressor.GetStatus() == AsyncStatus::Completed) {
        std::cout << "\n\nSuccess: test.7z created!" << std::endl;
        return 0;
    } else {
        std::cout << "\n\nFailed!" << std::endl;
        return 1;
    }
}
